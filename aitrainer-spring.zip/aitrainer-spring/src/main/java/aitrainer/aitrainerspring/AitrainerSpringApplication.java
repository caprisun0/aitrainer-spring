package aitrainer.aitrainerspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AitrainerSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AitrainerSpringApplication.class, args);
	}

}
