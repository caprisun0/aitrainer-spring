package aitrainer.aitrainerspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AitrainerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
